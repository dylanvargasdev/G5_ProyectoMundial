/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.proyectomundial;

import javax.swing.JOptionPane;

/**
 *
 * @author Dylan
 */
public class ProyectoMundial {

    public static void main(String[] args) {
        int opcionCapacidad = 0;
        int cantidadSedes = 0;
        int capacidad = 0;
        
        //Selección de tamaño del torneo.
        do{
            opcionCapacidad = Integer.parseInt(JOptionPane.showInputDialog("Seleccione la cantidad de países participantes:\n"
                    + "1. 24 Equipos\n"
                    + "2. 32 Equipos\n"
                    + "3. 48 Equipos\n"
                    + "4. 64 Equipos"));
            
            switch (opcionCapacidad) {

                case 1:
                    capacidad = 24;
                    break;

                case 2:
                    capacidad = 32;
                    break;

                case 3:
                    capacidad = 48;
                    break;
                    
                case 4:
                    capacidad = 64;
                    break;

                default:
                    JOptionPane.showMessageDialog(null, "Opción no válida.");
            }
        }while(capacidad != 16 && capacidad != 24 && capacidad != 32 && capacidad != 64);
        
        //Arreglo de objeto Equipo y asignación de tamaño.
        Equipo[] equipos = new Equipo[capacidad];
        
        //Arreglo de objeto CuerpoArbitral y asignación de tamaño.
        CuerpoArbitral[] arbitros = new CuerpoArbitral[30];
        
        //Arreglo de objeto CuerpoArbitral y asignación de tamaño.
        cantidadSedes = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la cantidad de sedes del torneo: "));
        Sede[] sedes = new Sede[cantidadSedes];
        
        //Menú provisional para activar métodos.
        int opcion;
        do {

            opcion = Integer.parseInt(JOptionPane.showInputDialog(
                    "===== MENÚ =====\n"
                    + "1. Nuevo Equipo\n"
                    + "2. Ver Equipos\n"
                    + "3. Actualizar Equipo\n"
                    + "4. Nuevo Arbitro\n"  
                    + "5. Ver Arbitros\n" 
                    + "6. Actualizar Arbitro\n"    
                    + "7. Nueva Sede\n"  
                    + "8. Ver Sedes\n" 
                    + "9. Actualizar Sede\n"    
                    + "10. Modo Demo\n"  
                    + "11. Salir\n\n"
                    + "Seleccione una opción:"
            ));

            switch (opcion) {

                case 1:

                    Equipo.agregarEquipo(equipos);
                    break;

                case 2:
                    Equipo.mostrarEquipos(equipos);
                    break;
                    
                case 3:
                    Equipo.actualizarEquipos(equipos);
                    break;
                
                case 4:
                    CuerpoArbitral.agregarArbitro(arbitros);
                    break;
                    
                case 5:
                    CuerpoArbitral.mostrarArbitros(arbitros);
                    break;
                    
                case 6:
                    CuerpoArbitral.actualizarArbitros(arbitros);
                    break;
                
                case 7:
                    Sede.agregarSede(sedes);
                    break;
                    
                case 8:
                    Sede.mostrarSedes(sedes);
                    break;
                    
                case 9:
                    Sede.actualizarSedes(sedes);
                    break;
                
                case 10:
                    Equipo.modoDemoEquipos(equipos);
                    CuerpoArbitral.modoDemoArbitros(arbitros);
                    Sede.modoDemoSedes(sedes);
                    JOptionPane.showMessageDialog(null, "Modo demo completado.");
                    break;

                case 11:
                    JOptionPane.showMessageDialog(null, "Saliendo del sistema...");
                    break;

                default:
                    JOptionPane.showMessageDialog(null, "Opción no válida.");
            }

        } while (opcion != 11);

        
    }
}
